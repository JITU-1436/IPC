struct request
{


	char oper;
	int opr1;
	int opr2;


};

